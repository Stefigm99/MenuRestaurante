import java.util.Scanner;

public class EjemploArray {
    public static void main(String[] args) {
        // Creamos un objeto Scanner para leer la entrada del usuario
        Scanner scanner = new Scanner(System.in);

        // Pedimos al usuario que ingrese la cantidad de frutas que desea ingresar
        System.out.print("Ingrese la cantidad de frutas: ");
        int cantidadFrutas = scanner.nextInt();
        scanner.nextLine(); // Limpiamos el buffer del Scanner

        // Creamos el array con la cantidad de frutas ingresada por el usuario
        String[] frutas = new String[cantidadFrutas];

        // Pedimos al usuario que ingrese cada nombre de fruta
        for (int i = 0; i < cantidadFrutas; i++) {
            System.out.print("Ingrese el nombre de la fruta " + (i + 1) + ": ");
            frutas[i] = scanner.nextLine();
        }

        // Mostramos las frutas ingresadas por el usuario
        System.out.println("Las frutas ingresadas son:");
        for (int i = 0; i < cantidadFrutas; i++) {
            System.out.println(frutas[i]);
        }
    }
}


